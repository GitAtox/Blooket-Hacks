 Find the hack you want
- Click the copy button
- Go to the Blooket page
- Right click and click inspect
- Click console and top of the page
- Paste the code in at the bottom of the page in the console box
- Click enter and then click the X in the top corner of the console